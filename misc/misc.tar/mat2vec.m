% Convert matrix to a vector (written by Libi Hertzberg)
function vec = mat2vec(mat)

vec = mat(:);
