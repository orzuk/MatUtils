% Return the shorter side of an array
function w = my_width(x)
w = min(size(x));
