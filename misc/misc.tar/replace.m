% Replace every occurance of a in x by b
function x = replace(x,a,b)
x(x == a) = b;

