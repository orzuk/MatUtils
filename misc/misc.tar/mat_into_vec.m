% Convert matrix to a vector (written by Libi Hertzberg)
function vec = mat_into_vec(mat)

vec = mat(:);