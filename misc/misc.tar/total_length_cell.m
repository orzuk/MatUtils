% Compute the total length of elements in a cell array 
function l = total_length_cell(c)
l= sum(length_cell(c));
