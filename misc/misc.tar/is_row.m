% Check if a vector is a row vector
function a = is_row(v)
a = (size(v,1) == 1);
