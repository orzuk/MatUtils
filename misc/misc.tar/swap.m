% Swap two elements 
function [A, B] = swap(A,B)
tmp = A; 
A = B; 
B = tmp; 
